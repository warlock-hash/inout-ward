
<div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href="mainPanel.php"><img class="main-logo" src="assets/img/logo/logo.png" alt="" /></a>
                <strong><a href="mainPanel.php"><img src="assets/img/logo/logosn.png" alt="" /></a></strong>
            </div>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li class="active">
                            <a href="mainPanel.php"><i class="menu-icon fa fa-laptop"></i>Home </a>
                        </li>
                        <li class="menu-item-has-children dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-sign-out"></i>Outward</a>
                            <ul class="sub-menu children dropdown-menu">
                                <li><i class="menu-icon fa fa-sign-in"></i><a href="letter_outward.php">Outward A Letter</a></li>
                                <li><i class="menu-icon fa fa-sign-in"></i><a href="outward_view.php">Outward's Letter</a></li>
                                <li><i class="menu-icon fa fa-sign-in"></i><a href="outward_through_proper_channel.php">Outward Through Proper Channel</a></li>
                            </ul>
                        </li>

                        <li class="menu-item-has-children dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> <i class="menu-icon fa fa-sign-in"></i>Inward</a>
                            <ul class="sub-menu children dropdown-menu">
                                <li><i class="menu-icon fa fa-sign-in"></i><a href="inward_view.php">Inward's Letter</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </nav>
    </div>