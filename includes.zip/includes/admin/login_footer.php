
  
  <!--   Core JS Files   -->

  
  <script src="../public/assets/js/core/jquery.min.js" type="text/javascript"></script>
  <script src="../public/assets/js/core/popper.min.js" type="text/javascript"></script>
  <script src="../public/assets/js/core/bootstrap-material-design.min.js" type="text/javascript"></script>
  
  <!--  Plugin for the Sliders, full documentation here: http://refreshless.com/nouislider/ -->
  <script src="../public/assets/js/plugins/nouislider.min.js" type="text/javascript"></script>
  <!--  Google Maps Plugin    -->
  <script src="https://maps.googleapis.com/maps/api/js?key=YOUR_KEY_HERE"></script>
  <!-- Control Center for Material Kit: parallax effects, scripts for the example pages etc -->
  <script src="../public/assets/js/material-kit.js?v=2.0.5" type="text/javascript"></script>
 <footer class="footer" data-background-color="black">
    <div class="container">
      <nav class="float-left">
        <ul>
          <li>
            <a href="../public/developer_team.php">
              Developer Team
            </a>
          </li>
          
        </ul>
      </nav>
      <div class="copyright float-right">
        &copy;2019, Powerd By 
        <a href="http://usindh.edu.pk/itsc/" target="_blank">IT Services Center University Of Sindh Jamshoro</a>
      </div>
    </div>
  </footer>
   
</body>

</html>



