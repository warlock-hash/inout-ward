<div class="footer-copyright-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        <div class="footer-copy-right" style="padding-left: 20px;text-align:left">
                           

                        
                        
                    </div>
                </div>
                <div class="footer-copy-right" style="padding-right: 20px;text-align:right">
                           
                            <p> &copy;2019, Powerd By . <a href="http://usindh.edu.pk/itsc/" target="_blank">IT Services Center University Of Sindh</a></p>
                        
                        
                    </div>
            </div>
        </div>