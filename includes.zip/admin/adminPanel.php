
<?php require_once "../includes/admin/header.php";?>
    <!--[if lt IE 8]>
		<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
	<![endif]-->
    <!-- Start Left menu area -->
   <?php require_once "../includes/admin/side_bar.php";?> 
    <!-- End Left menu area -->
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <?php require_once "../includes/admin/nav.php";?> 
            
        
        <div id = "min-height" class="container-fluid" style="padding:30px">

        </div>
        
         <?php require_once "../includes/admin/footer_area.php";?>
    </div>

   <?php require_once "../includes/admin/footer.php";?>