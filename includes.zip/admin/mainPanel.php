
<?php require_once "../includes/admin/header.php";?>
    <!--[if lt IE 8]>
		<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
	<![endif]-->
    <!-- Start Left menu area -->
   <?php require_once "../includes/admin/side_bar.php";?> 
    <!-- End Left menu area -->
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <?php require_once "../includes/admin/nav.php";?> 

        <?php
            $obj=$_SESSION['Member_obj'];
            $status=false;
            $status_mesg="";
            if(isset($_GET['status'])){
                $status=true;
                $status_mesg=$_GET['status'];
            }

        ?>
        
        <div id = "min-height" class="container-fluid" style="padding:30px">
            <div class="content">
                <div class="row">
                    <div class="col-md-1"></div>
                    <div class="col-md-10" style="text-align: center">
                        <h4><?php echo $obj[0]['DEPT_NAME'];?></h4>
                    </div>
                    <div class="col-md-1"></div>
                </div>

                <div class="row">
                    <div class="col-lg-1 col-md-1"></div>
                    <div class="col-lg-3 col-md-6">
                        <a href="inward_view.php">
                            <div class="card" >
                                <div class="card-header" style="height:90px;text-align:center;">
                                    <h6 style="padding-top:8%">Inward's Letter</h6>
                                </div>
                                <div class="card-body " style="text-align:center;">

                                    <img src="images/receiving.png" alt="Inward's Letter" style="max-height:200px;" >
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4"></div>
                    <div class=" col-lg-3 col-md-6">
                        <a href="outward_menu.php">
                            <div class="card" >
                                <div class="card-header" style="height:90px;text-align:center;">
                                    <h6 style="padding-top:8%">Outward Menu</h6>
                                </div>
                                <div class="card-body " style="text-align:center;">

                                    <img src="images/sending.png" alt="Outward A Letter" style="max-height:200px;" >
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-1 col-md-1"></div>
                </div>
                <div class="row">
                    <div class="col-lg-1"></div>
                    <div class="col-lg-10">
                        <?php
                        if ($status && $status_mesg=="yes"){
                            echo "<div class='row'>
                                             <div class='col-md-1'></div>
                                             <div class='col-md-10'>
                                                <div class='alert-info' style='text-align: center; '>
                                                    <label style='font-size: x-large;'>Your Letter Has been Sent Successfully</label>
                                                </div>
                                             </div>
                                             <div class='col-md-1'></div>
                                          </div>";
                        }
                        if ($status && $status_mesg=="no"){
                            echo "<div class='row'>
                                             <div class='col-md-1'></div>
                                             <div class='col-md-10'>
                                                <div class='alert-danger' style='text-align: center; '>
                                                    <label style='font-size: x-large;'>Some thing went wrong letter can not be sended</label>
                                                </div>
                                             </div>
                                             <div class='col-md-1'></div>
                                          </div>";
                        }
                        if ($status && $status_mesg=="update_success"){
                            echo "<div class='row'>
                                             <div class='col-md-1'></div>
                                             <div class='col-md-10'>
                                                <div class='alert-info' style='text-align: center; '>
                                                    <label style='font-size: x-large;'>Your Latter Has Been Updated...</label>
                                                </div>
                                             </div>
                                             <div class='col-md-1'></div>
                                          </div>";
                        }
                        ?>
                    </div>
                    <div class="col-lg-1"></div>
                </div>

            </div>
        </div>
        
         <?php require_once "../includes/admin/footer_area.php";?>
    </div>

   <?php require_once "../includes/admin/footer.php";?>