<?php
//require "../db/db.php";

function getConnection(){
//    $server = "162.216.113.196";
//    $username = "drgs123";
//    $password = "ka5hifshaikh";
//    $database = "drgs123_admission";
    $server = "localhost";
    $username = "root";
    $password = "";
    $database = "inward_outward";
    $con=mysqli_connect($server,$username,$password,$database);
    if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
        return false;
    }else{
        //echo "Connected";
        return $con;
    }

}

function getDataStaticQuery($columns,$tables,$condition){
    $con = getConnection();
    $query = "SELECT $columns from $tables where $condition";
    $result = mysqli_query($con, $query);
    if (!$result) {
        die( "dead" . mysqli_error($con));
        return false;
    }
    $list = array();
    $i=0;
    while ($row = mysqli_fetch_assoc($result)){
        $list[$i] = $row;
        $i++;
    }
    return $list;

}

function isValidData($data){

    $data  =   addslashes(trim($data));
    return $data;
}


function isValidAdmin($username,$password){
    $coulmn="DEPT_ID,FAC_ID,INST_ID,DEPT_NAME,IS_INST,`CODE`,REMARKS,USER_TEMP AS USERNAME,PASS_TEMP AS PASSWORD,CITY_NAME";
    $table="department";
    $condition="((USER_TEMP='$username' AND PASS_TEMP='$password') AND (INST_ID = 0 AND (IS_INST ='Y' OR IS_INST = 'N')))";
    $obj=getDataStaticQuery($coulmn,$table,$condition);
    return $obj;
}

function getUserInfo($dept_id)
{
    $coulmn = "DEPT_ID,FAC_ID,INST_ID,DEPT_NAME,IS_INST,`CODE`,REMARKS,USER_TEMP AS USERNAME,CITY_NAME";
    $table = "department";
    $condition = "((DEPT_ID='$dept_id') AND (INST_ID = 0 AND (IS_INST ='Y' OR IS_INST = 'N')))";
    $obj = getDataStaticQuery($coulmn, $table, $condition);
    return $obj;
}